import json
import os
import errno
import msvcrt
import hashlib
import hmac
import sqlite3
import sys
from contextlib import closing
import tkinter as tk
from tkinter import ttk, messagebox
from dataclasses import dataclass, asdict
from datetime import date
from pathlib import Path


# Save user data beside the executable while loading bundled assets from the
# temporary PyInstaller directory when the app is packaged.
APP_DIR = Path(sys.executable if getattr(sys, "frozen", False) else __file__).resolve().parent
ASSET_DIR = Path(getattr(sys, "_MEIPASS", APP_DIR))
DATA_FILE = APP_DIR / "a_unifind_records.json"
ACCOUNT_FILE = DATA_FILE.with_name("a_unifind_staff.sqlite3")
LOGO_FILE = ASSET_DIR / "a_unifind_logo.png"


class SingleInstanceLock:
    """Windows byte-range lock shared by copies using the same records file.

    Keep the lock file: deleting it could let another process lock a different
    file. Windows releases the held byte automatically if the process exits.
    """
    def __init__(self, path):
        self.path = path
        self.handle = None

    def acquire(self):
        handle = self.path.open("a+b")
        try:
            handle.seek(0, os.SEEK_END)
            if handle.tell() == 0:
                handle.write(b"\0")
                handle.flush()
            handle.seek(0)
            try:
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError as error:
                if error.errno in (errno.EACCES, errno.EAGAIN, errno.EDEADLK):
                    handle.close()
                    return False
                raise
            self.handle = handle
            return True
        except BaseException:
            handle.close()
            raise

    def release(self):
        if self.handle is not None:
            try:
                self.handle.seek(0)
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
            finally:
                self.handle.close()
                self.handle = None


class StaffAccounts:
    """Local credentials using salted PBKDF2 hashes, never plaintext passwords."""
    def __init__(self, path):
        self.path = path
        with closing(sqlite3.connect(path)) as connection, connection:
            connection.execute(
                "CREATE TABLE IF NOT EXISTS staff (username TEXT PRIMARY KEY, "
                "salt BLOB NOT NULL, digest BLOB NOT NULL, iterations INTEGER NOT NULL)"
            )

    def has_accounts(self):
        with closing(sqlite3.connect(self.path)) as connection, connection:
            return connection.execute("SELECT 1 FROM staff LIMIT 1").fetchone() is not None

    def create_first(self, username, password):
        username = " ".join(username.split())
        if not 3 <= len(username) <= 40 or not all(ch.isalpha() or ch == " " for ch in username):
            raise ValueError("Staff name must be 3–40 letters and spaces; numbers and symbols are not allowed.")
        if not 8 <= len(password) <= 30:
            raise ValueError("Password must contain 8–30 characters.")
        salt = os.urandom(16)
        iterations = 600000
        digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, iterations)
        with closing(sqlite3.connect(self.path)) as connection, connection:
            connection.execute("BEGIN IMMEDIATE")
            if connection.execute("SELECT 1 FROM staff LIMIT 1").fetchone():
                raise ValueError("Staff setup is already complete. Please sign in.")
            connection.execute("INSERT INTO staff VALUES (?, ?, ?, ?)",
                               (username, salt, digest, iterations))

    def verify(self, username, password):
        # Keep existing credentials valid if created under the previous limit.
        if len(password) > 128:
            return False
        with closing(sqlite3.connect(self.path)) as connection, connection:
            row = connection.execute(
                "SELECT salt, digest, iterations FROM staff WHERE username = ?",
                (" ".join(username.split()),),
            ).fetchone()
        salt, expected, iterations = row if row else (b"\0" * 16, b"\0" * 32, 600000)
        actual = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, iterations)
        return row is not None and hmac.compare_digest(actual, expected)

CATEGORIES = (
    "Electronics",
    "School Supplies",
    "Clothing",
    "Bags",
    "Keys",
    "Accessories",
    "Other",
)


# =========================================================
# DATA RECORD
# =========================================================

@dataclass
class FoundItem:
    item_id: int
    name: str
    category: str
    description: str
    location_found: str
    date_found: str
    storage_location: str
    status: str = "Unclaimed"


# =========================================================
# SINGLY LINKED LIST
# =========================================================

class Node:
    def __init__(self, item):
        self.item = item
        self.next = None


class ItemLinkedList:
    def __init__(self):
        self.head = None
        self.tail = None
        self.size = 0

    def append(self, item):
        """Insert at the tail in O(1) time."""
        new_node = Node(item)

        if self.head is None:
            self.head = new_node
        else:
            self.tail.next = new_node

        self.tail = new_node
        self.size += 1

    def sort_by_date(self, newest_first=False):
        """Stable insertion sort by relinking nodes; O(n^2) worst case.

        Uses O(1) extra space. ISO YYYY-MM-DD strings compare by date.
        """
        sorted_head = None
        current = self.head
        while current is not None:
            following = current.next
            previous = None
            position = sorted_head
            while position is not None:
                if newest_first:
                    comes_before = current.item.date_found > position.item.date_found
                else:
                    comes_before = current.item.date_found < position.item.date_found
                if comes_before:
                    break
                previous = position
                position = position.next
            current.next = position
            if previous is None:
                sorted_head = current
            else:
                previous.next = current
            current = following

        self.head = sorted_head
        self.tail = sorted_head
        while self.tail is not None and self.tail.next is not None:
            self.tail = self.tail.next

    def remove_by_id(self, item_id):
        """Find and unlink a node; O(n) worst case."""
        previous = None
        current = self.head
        while current is not None:
            if current.item.item_id == item_id:
                if previous is None:
                    self.head = current.next
                else:
                    previous.next = current.next
                if current is self.tail:
                    self.tail = previous
                self.size -= 1
                return current.item
            previous = current
            current = current.next
        return None

    def find_by_id(self, item_id):
        """Find one record by traversing nodes; O(n) worst case."""
        current = self.head
        while current is not None:
            if current.item.item_id == item_id:
                return current.item
            current = current.next
        return None

    def search(self, keyword):
        """Linear search through every node; O(n) for bounded fields."""
        keyword = keyword.strip().casefold()
        current = self.head
        while current is not None:
            item = current.item
            if (
                keyword in item.name.casefold()
                or keyword in item.category.casefold()
                or keyword in item.location_found.casefold()
            ):
                yield item
            current = current.next

    def __iter__(self):
        """Visit every record from head to tail."""
        current = self.head

        while current is not None:
            yield current.item
            current = current.next


# =========================================================
# FILE STORAGE
# =========================================================

def load_records():
    """Read JSON and rebuild the linked list."""
    items = ItemLinkedList()

    if not DATA_FILE.exists():
        return items, 1

    with DATA_FILE.open("r", encoding="utf-8") as file:
        saved_data = json.load(file)

    if not isinstance(saved_data, dict):
        raise ValueError("The saved file must contain a JSON object.")

    if saved_data.get("version") != 1:
        raise ValueError("The saved file version is not supported.")

    records = saved_data.get("items")
    next_id = saved_data.get("next_id")

    if not isinstance(records, list):
        raise ValueError("The saved item collection is invalid.")

    if type(next_id) is not int or next_id < 1:
        raise ValueError("The saved next ID is invalid.")

    seen_ids = set()
    highest_id = 0

    for record in records:
        if not isinstance(record, dict):
            raise ValueError("A saved record is not a JSON object.")

        try:
            item = FoundItem(**record)
        except TypeError as error:
            raise ValueError("A saved record has invalid fields.") from error

        if type(item.item_id) is not int or item.item_id < 1:
            raise ValueError("A saved item has an invalid ID.")

        if item.item_id in seen_ids:
            raise ValueError("The saved file contains duplicate IDs.")

        required_text = (
            item.name,
            item.category,
            item.location_found,
            item.date_found,
            item.storage_location,
        )

        if not all(
            isinstance(value, str) and value.strip()
            for value in required_text
        ):
            raise ValueError("A saved item is missing required information.")

        if not isinstance(item.description, str):
            raise ValueError("A saved description is invalid.")

        if item.category not in CATEGORIES:
            raise ValueError("A saved category is invalid.")

        if item.status not in ("Unclaimed", "Claimed"):
            raise ValueError("A saved status is invalid.")

        parsed_date = date.fromisoformat(item.date_found)

        if parsed_date.isoformat() != item.date_found:
            raise ValueError("A saved date must use YYYY-MM-DD format.")

        seen_ids.add(item.item_id)
        highest_id = max(highest_id, item.item_id)
        items.append(item)

    if next_id <= highest_id:
        raise ValueError("The saved next ID conflicts with existing records.")

    return items, next_id


def save_records(items, next_id, new_item=None, exclude_id=None, replacement=None):
    """Save a snapshot before committing a new item to memory."""
    records = [
        asdict(replacement if replacement is not None and item.item_id == replacement.item_id else item)
        for item in items if item.item_id != exclude_id
    ]

    if new_item is not None:
        records.append(asdict(new_item))

    saved_data = {
        "version": 1,
        "next_id": next_id,
        "items": records,
    }

    temporary_file = DATA_FILE.with_suffix(".json.tmp")

    try:
        # Write a complete temporary file before replacing the old file.
        with temporary_file.open("w", encoding="utf-8") as file:
            json.dump(saved_data, file, indent=2, ensure_ascii=False)
            file.flush()
            os.fsync(file.fileno())

        os.replace(temporary_file, DATA_FILE)

    finally:
        # Clean up an incomplete temporary file if saving failed.
        try:
            temporary_file.unlink(missing_ok=True)
        except OSError:
            pass


# =========================================================
# GRAPHICAL USER INTERFACE
# =========================================================

class LostAndFoundApp:
    def __init__(self, root, items, next_id, accounts=None):
        self.root = root
        self.items = items
        self.next_id = next_id
        self.add_window = None
        self.staff_user = None
        self.logo_image = None
        if LOGO_FILE.exists():
            try:
                self.logo_image = tk.PhotoImage(file=str(LOGO_FILE))
                root.iconphoto(True, self.logo_image)
            except tk.TclError:
                self.logo_image = None
        self.accounts = accounts if accounts is not None else StaffAccounts(ACCOUNT_FILE)

        root.title("A-UniFind | Lost and Found System")
        root.geometry("1240x740")
        root.minsize(1000, 620)

        style = ttk.Style(root)
        style.theme_use("clam")
        root.configure(background="#f6f7fa")
        style.configure("TFrame", background="#f6f7fa")
        style.configure("TLabel", background="#f6f7fa", foreground="#263550", font=("Segoe UI", 10))
        style.configure("TButton", font=("Segoe UI", 10), padding=(12, 8))
        style.configure("Primary.TButton", background="#3b5191", foreground="white")
        style.map("Primary.TButton", background=[("active", "#2b407c")])
        style.configure("Treeview", rowheight=32, font=("Segoe UI", 10), background="white", fieldbackground="white")
        style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"), padding=8)
        style.configure("TButton", background="white", foreground="#3b5191", bordercolor="#dce1ea", lightcolor="white", darkcolor="white", relief="flat")
        style.map("TButton", background=[("active", "#e9edf6")])
        style.configure("Primary.TButton", borderwidth=0, relief="flat")
        style.configure("TScrollbar", background="#e6e9f0", troughcolor="#f5f6fa", bordercolor="#f5f6fa", lightcolor="#e6e9f0", darkcolor="#e6e9f0", arrowcolor="#74809a")
        style.configure("TCombobox", fieldbackground="white", background="#eef0f6", bordercolor="#dce1ea", arrowcolor="#64708a")
        # Override clam's gray read-only and hover states.
        style.map("TCombobox",
                  fieldbackground=[("disabled", "#f0f2f6"), ("readonly", "white")],
                  background=[("disabled", "#f0f2f6"), ("active", "#e2e8f4"), ("readonly", "white")],
                  foreground=[("disabled", "#8b94a5"), ("readonly", "#263550")],
                  selectbackground=[("readonly", "white")],
                  selectforeground=[("readonly", "#263550")],
                  bordercolor=[("focus", "#3b5191")],
                  arrowcolor=[("disabled", "#8b94a5"), ("readonly", "#3b5191")])
        style.map("Primary.TButton", background=[("disabled", "#dfe3ec"), ("active", "#2b407c")], foreground=[("disabled", "#738099")])
        style.configure("Side.TFrame", background="#eef0f6")
        style.configure("SideMuted.TLabel", background="#eef0f6", foreground="#717b91")
        style.configure("Brand.TLabel", background="#eef0f6", foreground="#3b5191", font=("Segoe UI", 20, "bold"))
        style.configure("Muted.TLabel", foreground="#707b8f")
        style.configure("Card.TFrame", background="white")
        style.configure("Card.TLabel", background="white")
        style.configure("CardMuted.TLabel", background="white", foreground="#707b8f")
        style.configure("Nav.TButton", background="#eef0f6", foreground="#58647d", borderwidth=0, anchor="w", padding=(12, 12))
        style.map("Nav.TButton", background=[("active", "#e2e7f1")])
        style.configure("NavSelected.TButton", background="#dfe5f4", foreground="#30487e", borderwidth=0, anchor="w", padding=(12, 12), font=("Segoe UI", 10, "bold"))
        style.map("NavSelected.TButton", background=[("active", "#d4ddef")])
        style.configure("Danger.TButton", foreground="#9a404b", background="white", borderwidth=0)
        style.map("Danger.TButton", background=[("active", "#f8edf0")])
        style.configure("TEntry", fieldbackground="white", bordercolor="#dce1ea", lightcolor="#dce1ea", darkcolor="#dce1ea")
        style.configure("Treeview", borderwidth=0, rowheight=38, foreground="#344159")
        style.configure("Treeview.Heading", background="#eef0f6", foreground="#64708a", relief="flat", font=("Segoe UI", 9, "bold"))
        style.map("Treeview.Heading",
                  background=[("pressed", "#d4ddef"), ("active", "#e0e6f2")],
                  foreground=[("pressed", "#263f78"), ("active", "#263f78")],
                  relief=[("pressed", "flat"), ("active", "flat")])
        style.map("Treeview", background=[("selected", "#dce4f5")], foreground=[("selected", "#263f78")])
        root.bind_all('<Button-1>', self.clear_filter_focus_on_background, add='+')
        self.show_home()

    def clear_filter_focus_on_background(self, event):
        # Tkinter leaves a combobox focused when a plain frame or label is clicked.
        if (isinstance(self.root.focus_get(), ttk.Combobox)
                and event.widget.winfo_class() in ('TFrame', 'Frame', 'TLabel', 'Label', 'Canvas')):
            self.root.after_idle(self.root.focus_set)

    def clear_screen(self):
        # Close private dialogs too when leaving staff mode.
        for child in self.root.winfo_children():
            child.destroy()
        self.add_window = None

    def show_home(self):
        self.staff_user = None
        self.clear_screen()
        frame = ttk.Frame(self.root, padding=40)
        frame.place(relx=0.5, rely=0.45, anchor="center")
        if self.logo_image is not None:
            ttk.Label(frame, image=self.logo_image).pack(anchor="center", pady=(0, 10))
        else:
            ttk.Label(frame, text="A-UniFind", font=("Segoe UI", 36, "bold")).pack(anchor="w")
        ttk.Label(frame, text="Lost something? Start here.", font=("Segoe UI", 18)).pack(anchor="w", pady=(8, 20))
        ttk.Label(frame, text="Browse found belongings, then speak with staff to verify ownership.\nItem returns are handled in person.").pack(anchor="w", pady=(0, 24))
        ttk.Button(frame, text="Browse Items", style="Primary.TButton", command=self.open_browse).pack(fill="x", pady=5)
        ttk.Button(frame, text="Staff Login", command=self.open_login).pack(fill="x", pady=5)
        ttk.Label(frame, text="Campus Lost and Found Management System").pack(pady=(24, 0))

    def open_browse(self):
        self.staff_user = None
        self.clear_screen()
        self.build_interface()
        self.refresh_table()

    def require_staff(self):
        if self.staff_user is not None:
            return True
        messagebox.showwarning("Staff Access Required", "Sign in as staff to manage records.", parent=self.root)
        return False

    def open_login(self):
        try:
            setup = not self.accounts.has_accounts()
        except sqlite3.Error as error:
            messagebox.showerror("Account File Error", str(error), parent=self.root)
            return
        self.clear_screen()
        frame = ttk.Frame(self.root, padding=30)
        frame.place(relx=0.5, rely=0.45, anchor="center")
        ttk.Label(frame, text="Set up staff access" if setup else "Staff sign in", font=("Segoe UI", 24, "bold")).pack(anchor="w", pady=(0, 12))
        ttk.Label(frame, text="First use: the responsible operator creates the staff account." if setup else "Manage found items and record their return.", wraplength=420).pack(anchor="w", pady=(0, 16))
        variables = {}
        fields = ["Staff name", "Password"] + (["Confirm password"] if setup else [])
        if setup:
            ttk.Label(frame, text="Staff name: letters and spaces only (3–40 characters).", wraplength=420).pack(anchor="w")
            ttk.Label(frame, text="Password: 8–30 characters. Spaces and symbols are allowed.", wraplength=420).pack(anchor="w")
        for label in fields:
            ttk.Label(frame, text=label).pack(anchor="w", pady=(8, 4))
            variables[label] = tk.StringVar()
            entry = ttk.Entry(frame, textvariable=variables[label], show="" if label == "Staff name" else "*", width=40)
            if setup and label == "Staff name":
                # Reject invalid typing and pasted text before it reaches the field.
                entry.configure(
                    validate="key",
                    validatecommand=(entry.register(
                        lambda proposed: len(proposed) <= 40
                        and all(char.isalpha() or char == " " for char in proposed)
                    ), "%P"),
                )
            entry.pack(fill="x")
        feedback = tk.StringVar()
        ttk.Label(frame, textvariable=feedback, wraplength=420, foreground="#a12626").pack(pady=12)

        def submit():
            username = variables["Staff name"].get().strip()
            password = variables["Password"].get()
            try:
                if setup:
                    if password != variables["Confirm password"].get():
                        raise ValueError("Passwords do not match.")
                    self.accounts.create_first(username, password)
                elif not self.accounts.verify(username, password):
                    raise ValueError("Incorrect staff name or password.")
            except (ValueError, sqlite3.Error) as error:
                feedback.set(str(error))
                variables["Password"].set("")
                if setup:
                    variables["Confirm password"].set("")
                return
            self.staff_user = " ".join(username.split())
            for variable in variables.values():
                variable.set("")
            self.clear_screen()
            self.build_interface()
            self.refresh_table()

        ttk.Button(frame, text="Create staff account" if setup else "Sign in", style="Primary.TButton", command=submit).pack(fill="x", pady=5)
        ttk.Button(frame, text="Back", command=self.show_home).pack(fill="x", pady=5)

    def build_interface(self):
        self.refreshing = False
        self.active_section = 'All items' if self.staff_user else 'Unclaimed'
        tk.Frame(self.root, bg='#3b5191', height=6).pack(fill='x')
        shell = ttk.Frame(self.root)
        shell.pack(fill='both', expand=True)
        sidebar = ttk.Frame(shell, style='Side.TFrame', width=190, padding=(16, 26))
        sidebar.pack(side='left', fill='y')
        sidebar.pack_propagate(False)
        if self.logo_image is not None:
            # Tkinter subsample scales the same transparent logo without dependencies.
            self.sidebar_logo = self.logo_image.subsample(2, 2)
            ttk.Label(sidebar, image=self.sidebar_logo, style='SideMuted.TLabel').pack(anchor='center', pady=(0, 8))
        else:
            ttk.Label(sidebar, text='A-UniFind', style='Brand.TLabel').pack(anchor='w')
        ttk.Label(sidebar, text='CAMPUS LOST & FOUND', style='SideMuted.TLabel', font=('Segoe UI', 8)).pack(anchor='center', pady=(4, 32))
        ttk.Label(sidebar, text='COLLECTION', style='SideMuted.TLabel', font=('Segoe UI', 8, 'bold')).pack(anchor='w', pady=(0, 10))
        self.nav_buttons = {}
        for section in (('All items', 'Unclaimed', 'Claimed') if self.staff_user else ('Unclaimed',)):
            button = ttk.Button(sidebar, text=section, style='Nav.TButton', command=lambda value=section: self.select_section(value))
            button.pack(fill='x', pady=3)
            self.nav_buttons[section] = button
        ttk.Button(sidebar, text='Log out' if self.staff_user else 'Back to home', style='Nav.TButton', command=self.show_home).pack(side='bottom', fill='x')
        ttk.Label(sidebar, text=f'STAFF\n{self.staff_user}' if self.staff_user else 'STUDENT VIEW\nNo login needed', style='SideMuted.TLabel', wraplength=150).pack(side='bottom', anchor='w', pady=20)

        # Minimal divider between the navigation and workspace.
        tk.Frame(shell, bg='#dce1ea', width=1).pack(side='left', fill='y')

        main = ttk.Frame(shell, padding=(22, 24, 22, 12))
        main.pack(side='left', fill='both', expand=True)
        header = ttk.Frame(main)
        header.pack(fill='x', pady=(0, 22))
        self.section_title = tk.StringVar()
        ttk.Label(header, textvariable=self.section_title, font=('Segoe UI', 24, 'bold')).pack(side='left')
        if self.staff_user:
            ttk.Button(header, text='+ Add Item', style='Primary.TButton', command=self.open_add_form).pack(side='right')
        subtitle = 'Keep found belongings organized and record their return.' if self.staff_user else 'Find a possible match, then speak with staff to verify ownership.'
        ttk.Label(main, text=subtitle, style='Muted.TLabel').pack(anchor='w', pady=(0, 18))

        workspace = ttk.Frame(main)
        workspace.pack(fill='both', expand=True)
        workspace.columnconfigure(0, weight=1)
        workspace.columnconfigure(1, minsize=300)
        workspace.rowconfigure(0, weight=1)
        collection = ttk.Frame(workspace)
        collection.grid(row=0, column=0, sticky='nsew', padx=(0, 18))
        search_row = ttk.Frame(collection)
        search_row.pack(fill='x')
        ttk.Label(search_row, text='SEARCH', style='Muted.TLabel', font=('Segoe UI', 8, 'bold')).pack(anchor='w', pady=(0, 6))
        entry_row = ttk.Frame(search_row)
        entry_row.pack(fill='x')
        self.search_var = tk.StringVar()
        entry = ttk.Entry(entry_row, textvariable=self.search_var, width=16)
        entry.pack(side='left', fill='x', expand=True, ipady=5)
        entry.bind('<Return>', lambda event: self.refresh_table())
        ttk.Button(entry_row, text='Search', command=self.refresh_table).pack(side='left', padx=(8, 0))
        ttk.Button(entry_row, text='Reset', command=self.clear_search).pack(side='left', padx=(6, 0))
        ttk.Label(search_row, text='Item name, category or location', style='Muted.TLabel', font=('Segoe UI', 9)).pack(anchor='w', pady=(5, 12))
        filters = ttk.Frame(collection)
        filters.pack(fill='x', pady=(0, 14))
        self.category_var = tk.StringVar(value='All categories')
        self.sort_var = tk.StringVar(value='Oldest first')
        for label, variable, options, width in (
            ('Category', self.category_var, ('All categories',) + CATEGORIES, 18),
            ('Date found', self.sort_var, ('Oldest first', 'Newest first'), 14),
        ):
            group = ttk.Frame(filters)
            group.pack(side='left', padx=(0, 12))
            ttk.Label(group, text=label, style='Muted.TLabel').pack(anchor='w', pady=(0, 4))
            box = ttk.Combobox(group, textvariable=variable, values=options, state='readonly', width=width)
            box.pack(ipady=3)
            box.bind('<<ComboboxSelected>>', lambda event: self.refresh_table())

        table_frame = ttk.Frame(collection, style='Card.TFrame')
        table_frame.pack(fill='both', expand=True)
        columns = {'item_id': ('ID', 50), 'name': ('Item', 145), 'category': ('Category', 115), 'date_found': ('Date found', 105)}
        if self.staff_user:
            columns['status'] = ('Status', 95)
        self.table_columns = tuple(columns)
        self.item_table = ttk.Treeview(table_frame, columns=self.table_columns, show='headings', selectmode='browse', height=7)
        self.item_table.tag_configure('alternate', background='#f5f6fa')
        for column, (label, width) in columns.items():
            self.item_table.heading(column, text=label)
            self.item_table.column(column, width=width, minwidth=45, stretch=column=='name')
        vertical = ttk.Scrollbar(table_frame, orient='vertical', command=self.item_table.yview)
        horizontal = ttk.Scrollbar(table_frame, orient='horizontal', command=self.item_table.xview)
        self.item_table.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)
        table_frame.rowconfigure(0, weight=1)
        table_frame.columnconfigure(0, weight=1)
        if self.staff_user:
            self.item_table.grid(row=0, column=0, sticky='nsew')
            vertical.grid(row=0, column=1, sticky='ns')
            horizontal.grid(row=1, column=0, sticky='ew')
        else:
            self.card_canvas = tk.Canvas(table_frame, bg='#f6f7fa', highlightthickness=0)
            self.card_scroll = ttk.Scrollbar(table_frame, orient='vertical', command=self.card_canvas.yview)
            self.card_canvas.configure(yscrollcommand=self.card_scroll.set)
            self.card_canvas.grid(row=0, column=0, sticky='nsew')
            self.card_scroll.grid(row=0, column=1, sticky='ns')
            self.card_body = tk.Frame(self.card_canvas, bg='#f6f7fa')
            body_id = self.card_canvas.create_window((0, 0), window=self.card_body, anchor='nw')
            self.card_body.bind('<Configure>', lambda event: self.card_canvas.configure(scrollregion=self.card_canvas.bbox('all')))
            self.card_canvas.bind('<Configure>', lambda event: self.card_canvas.itemconfigure(body_id, width=event.width))
            self.card_canvas.bind('<MouseWheel>', self.scroll_cards)
            self.card_body.bind('<MouseWheel>', self.scroll_cards)
        self.item_table.bind('<<TreeviewSelect>>', self.selection_changed)
        self.item_table.bind('<Return>', lambda event: self.view_details())
        self.count_text = tk.StringVar()
        ttk.Label(collection, textvariable=self.count_text, style='Muted.TLabel').pack(anchor='w', pady=(10, 0))

        # One-pixel border, without changing the panel's allocated width.
        details_border = tk.Frame(workspace, bg='#dce1ea', width=300)
        details_border.grid(row=0, column=1, sticky='nsew')
        details_border.grid_propagate(False)
        self.details_panel = ttk.Frame(details_border, style='Card.TFrame', width=298)
        self.details_panel.pack(fill='both', expand=True, padx=1, pady=1)
        self.details_panel.grid_propagate(False)
        self.details_panel.columnconfigure(0, weight=1)
        self.details_panel.rowconfigure(1, weight=1)
        ttk.Label(self.details_panel, text='ITEM DETAILS', style='CardMuted.TLabel', padding=(20, 18), font=('Segoe UI', 9, 'bold')).grid(row=0, column=0, sticky='ew')
        scroll_frame = ttk.Frame(self.details_panel, style='Card.TFrame')
        scroll_frame.grid(row=1, column=0, sticky='nsew')
        scroll_frame.rowconfigure(0, weight=1)
        scroll_frame.columnconfigure(0, weight=1)
        self.detail_canvas = tk.Canvas(scroll_frame, background='white', highlightthickness=0, width=280)
        scroll = ttk.Scrollbar(scroll_frame, orient='vertical', command=self.detail_canvas.yview)
        self.detail_canvas.configure(yscrollcommand=scroll.set)
        self.detail_canvas.grid(row=0, column=0, sticky='nsew')
        scroll.grid(row=0, column=1, sticky='ns')
        self.detail_body = ttk.Frame(self.detail_canvas, style='Card.TFrame', padding=(20, 4, 20, 20))
        body_id = self.detail_canvas.create_window((0, 0), window=self.detail_body, anchor='nw')
        self.detail_body.bind('<Configure>', lambda event: self.detail_canvas.configure(scrollregion=self.detail_canvas.bbox('all')))
        self.detail_canvas.bind('<Configure>', lambda event: self.detail_canvas.itemconfigure(body_id, width=event.width))
        self.detail_actions = ttk.Frame(self.details_panel, style='Card.TFrame', padding=(16, 12))
        self.detail_actions.grid(row=2, column=0, sticky='ew')
        self.render_details(None)
        self.status_text = tk.StringVar()
        ttk.Label(main, textvariable=self.status_text, style='Muted.TLabel', wraplength=800).pack(anchor='w', pady=(12, 0))

    def select_section(self, section):
        if not self.staff_user and section != 'Unclaimed':
            return
        self.active_section = section
        self.refresh_table()

    def selection_changed(self, event=None):
        if not self.refreshing:
            self.view_details()

    def select_card(self, item_id):
        row_id = str(item_id)
        if self.item_table.exists(row_id):
            self.item_table.selection_set(row_id)
            self.view_details()
            for card_id, card in self.card_widgets.items():
                card.configure(bg='#9eafd5' if card_id == item_id else '#dce1ea')

    def scroll_cards(self, event):
        if event.delta:
            self.card_canvas.yview_scroll(-1 if event.delta > 0 else 1, 'units')
        return 'break'

    def render_cards(self, items):
        for child in self.card_body.winfo_children():
            child.destroy()
        self.card_widgets = {}
        selected = self.item_table.selection()
        selected_id = int(selected[0]) if selected else None
        for column in range(2):
            self.card_body.columnconfigure(column, weight=1, uniform='card')
        if not items:
            tk.Label(self.card_body, text='No items found', bg='#f6f7fa', fg='#263550',
                     font=('Segoe UI', 15, 'bold')).grid(row=0, column=0, sticky='w', padx=12, pady=(24, 4))
            tk.Label(self.card_body, text='Try a different search or category.', bg='#f6f7fa',
                     fg='#707b8f', font=('Segoe UI', 10)).grid(row=1, column=0, sticky='w', padx=12)
            return
        for index, item in enumerate(items):
            border = tk.Frame(self.card_body, bg='#9eafd5' if item.item_id == selected_id else '#dce1ea')
            border.grid(row=index // 2, column=index % 2, sticky='nsew', padx=7, pady=7)
            self.card_widgets[item.item_id] = border
            card = tk.Frame(border, bg='white', padx=15, pady=14)
            card.pack(fill='both', expand=True, padx=1, pady=1)
            border.bind('<MouseWheel>', self.scroll_cards)
            card.bind('<MouseWheel>', self.scroll_cards)
            labels = (
                (f'RECORD #{item.item_id}', '#707b8f', 8, 'bold'),
                (item.name, '#263550', 13, 'bold'),
                (item.category, '#3b5191', 9, 'bold'),
                (f'Found {date.fromisoformat(item.date_found):%b %d, %Y}', '#58647d', 9, 'normal'),
                (item.location_found, '#58647d', 9, 'normal'),
            )
            for row, (value, color, size, weight) in enumerate(labels):
                label = tk.Label(card, text=value, bg='white', fg=color,
                                 font=('Segoe UI', size, weight), anchor='w', justify='left',
                                 wraplength=170)
                label.pack(fill='x', pady=(0, 8 if row == 1 else 5))
                label.bind('<Button-1>', lambda event, item_id=item.item_id: self.select_card(item_id))
                label.bind('<MouseWheel>', self.scroll_cards)
            for widget in (border, card):
                widget.bind('<Button-1>', lambda event, item_id=item.item_id: self.select_card(item_id))

    def refresh_table(self):
        selected = self.item_table.selection()
        self.refreshing = True
        self.items.sort_by_date(newest_first=self.sort_var.get() == 'Newest first')
        for row in self.item_table.get_children():
            self.item_table.delete(row)
        keyword = self.search_var.get().strip()
        records = self.items.search(keyword) if keyword else self.items
        shown = 0
        visible_items = []
        for item in records:
            if not self.staff_user and item.status != 'Unclaimed':
                continue
            if self.active_section != 'All items' and item.status != self.active_section:
                continue
            if self.category_var.get() != 'All categories' and item.category != self.category_var.get():
                continue
            values = {'item_id': item.item_id, 'name': item.name, 'category': item.category,
                      'date_found': item.date_found, 'status': item.status}
            self.item_table.insert('', 'end', iid=str(item.item_id), values=tuple(values[c] for c in self.table_columns), tags=('alternate',) if shown % 2 else ())
            visible_items.append(item)
            shown += 1
        if selected and self.item_table.exists(selected[0]):
            self.item_table.selection_set(selected[0])
        if not self.staff_user:
            self.render_cards(visible_items)
        unclaimed = sum(item.status == 'Unclaimed' for item in self.items)
        counts = {'All items': self.items.size, 'Unclaimed': unclaimed, 'Claimed': self.items.size-unclaimed}
        for section, button in self.nav_buttons.items():
            button.configure(text=f'{section}  ({counts[section]})', style='NavSelected.TButton' if section==self.active_section else 'Nav.TButton')
        self.section_title.set('Found items' if not self.staff_user else self.active_section)
        self.count_text.set(f'{shown} item(s) shown')
        if not shown:
            self.status_text.set('No items match these filters.')
        elif keyword:
            self.status_text.set(f'Search results for "{keyword}".')
        else:
            self.status_text.set('Select a row to view its details.' if self.staff_user else 'Select a card to view its details.')
        self.refreshing = False
        self.view_details()

    def clear_search(self):
        self.search_var.set('')
        self.category_var.set('All categories')
        self.refresh_table()

    def render_details(self, item):
        for area in (self.detail_body, self.detail_actions):
            for child in area.winfo_children():
                child.destroy()
        self.detail_canvas.yview_moveto(0)
        if item is None:
            ttk.Label(self.detail_body, text='Select an item', style='Card.TLabel', font=('Segoe UI', 16, 'bold')).pack(anchor='w', pady=(18, 8))
            hint = 'Choose a row from the collection to see its information here.' if self.staff_user else 'Choose a card from the collection to see its information here.'
            ttk.Label(self.detail_body, text=hint, style='CardMuted.TLabel', wraplength=235, justify='left').pack(anchor='w')
            return
        ttk.Label(self.detail_body, text=f'RECORD #{item.item_id}', style='CardMuted.TLabel', font=('Segoe UI', 9)).pack(anchor='w', pady=(0, 8))
        ttk.Label(self.detail_body, text=item.name, style='Card.TLabel', font=('Segoe UI', 18, 'bold'), wraplength=235, justify='left').pack(anchor='w', pady=(0, 12))
        tk.Label(self.detail_body, text=item.status, background='#e9edf7' if item.status=='Unclaimed' else '#edf0f2', foreground='#344d83' if item.status=='Unclaimed' else '#505e6e', font=('Segoe UI', 9, 'bold'), padx=10, pady=5).pack(anchor='w', pady=(0, 22))
        # Separate the item's identity/status from its details.
        tk.Frame(self.detail_body, bg='#dce1ea', height=1).pack(fill='x', pady=(0, 20))
        fields = [('Category', item.category), ('Date found', date.fromisoformat(item.date_found).strftime('%B %d, %Y')), ('Location found', item.location_found)]
        if self.staff_user:
            fields += [('Kept at - Staff only', item.storage_location), ('Private description', item.description or 'No description provided.')]
        else:
            fields += [('How to inquire', 'Speak with the staff member operating A-UniFind and quote this record number. Bring identifying details to help verify ownership.')]
        for label, value in fields:
            ttk.Label(self.detail_body, text=label.upper(), style='CardMuted.TLabel', font=('Segoe UI', 8, 'bold')).pack(anchor='w', pady=(0, 5))
            ttk.Label(self.detail_body, text=value, style='Card.TLabel', wraplength=235, justify='left').pack(anchor='w', pady=(0, 18))
        if self.staff_user:
            # Separate record details from destructive/claim actions.
            tk.Frame(self.detail_actions, bg='#dce1ea', height=1).pack(fill='x', pady=(0, 14))
            ttk.Button(self.detail_actions, text='Edit Item', command=self.open_edit_form).pack(fill='x', pady=(0, 6))
            claim = ttk.Button(self.detail_actions, text='Mark as Claimed', style='Primary.TButton', command=self.mark_as_claimed)
            claim.pack(fill='x', pady=(0, 6))
            if item.status == 'Claimed':
                claim.state(['disabled'])
            ttk.Button(self.detail_actions, text='Delete Record', style='Danger.TButton', command=self.delete_record).pack(fill='x')

    def delete_record(self):
        if not self.require_staff():
            return
        selected = self.item_table.selection()
        if not selected:
            messagebox.showinfo(
                "Select an Item", "Select an item in the table first.",
                parent=self.root,
            )
            return
        item = self.items.find_by_id(int(selected[0]))
        if item is None:
            messagebox.showerror(
                "Item Not Found", "This record is no longer available.",
                parent=self.root,
            )
            self.refresh_table()
            return
        if not messagebox.askyesno(
            "Delete Record?",
            f'Permanently delete item #{item.item_id}: {item.name}?\n\n'
            "This removes the saved record and cannot be undone.\n"
            "For a returned item, use Mark as Claimed to keep its history.",
            icon="warning", default="no", parent=self.root,
        ):
            return
        try:
            # Save the remaining records before unlinking anything in memory.
            save_records(self.items, self.next_id, exclude_id=item.item_id)
        except OSError as error:
            messagebox.showerror(
                "Could Not Save",
                "The record was not deleted because saving failed.\n\n"
                f"Details: {error}", parent=self.root,
            )
            return
        self.items.remove_by_id(item.item_id)
        self.refresh_table()
        self.status_text.set(f"Deleted item #{item.item_id} and saved the change.")

    def mark_as_claimed(self):
        if not self.require_staff():
            return
        selected = self.item_table.selection()
        if not selected:
            messagebox.showinfo(
                "Select an Item", "Select an item in the table first.",
                parent=self.root,
            )
            return

        item = self.items.find_by_id(int(selected[0]))
        if item is None:
            messagebox.showerror(
                "Item Not Found", "This record is no longer available.",
                parent=self.root,
            )
            self.refresh_table()
            return
        if item.status == "Claimed":
            messagebox.showinfo(
                "Already Claimed", "This item has already been marked as claimed.",
                parent=self.root,
            )
            return

        confirmed = messagebox.askyesno(
            "Confirm Item Return",
            f'Item #{item.item_id}: {item.name}\n\n'
            "Have you verified ownership and returned this item to its owner?\n\n"
            "Choose Yes to mark it as claimed and save the change.",
            parent=self.root,
        )
        if not confirmed:
            return

        previous_status = item.status
        item.status = "Claimed"
        try:
            save_records(self.items, self.next_id)
        except OSError as error:
            # Restore memory too, so the display and saved file still agree.
            item.status = previous_status
            messagebox.showerror(
                "Could Not Save",
                "The claim was not saved. The item's status is unchanged.\n\n"
                f"Details: {error}",
                parent=self.root,
            )
            return

        self.refresh_table()
        row_id = str(item.item_id)
        if self.item_table.exists(row_id):
            self.item_table.selection_set(row_id)
            self.item_table.see(row_id)
        self.status_text.set(
            f"Item #{item.item_id} marked as claimed and saved."
        )

    def view_details(self):
        selected = self.item_table.selection()
        item = self.items.find_by_id(int(selected[0])) if selected else None
        if item is not None and not self.staff_user and item.status != "Unclaimed":
            item = None
        self.render_details(item)

    def open_add_form(self):
        self.open_item_form()

    def open_edit_form(self):
        if not self.require_staff():
            return
        selected = self.item_table.selection()
        if not selected:
            messagebox.showinfo("Select an Item", "Select an item in the table first.", parent=self.root)
            return
        item = self.items.find_by_id(int(selected[0]))
        if item is None:
            messagebox.showerror("Item Not Found", "This record is no longer available.", parent=self.root)
            self.refresh_table()
            return
        self.open_item_form(item)

    def open_item_form(self, existing=None):
        if not self.require_staff():
            return
        if self.add_window is not None:
            self.add_window.lift()
            return

        window = tk.Toplevel(self.root)
        self.add_window = window

        window.title(f"Edit Item #{existing.item_id} | A-UniFind" if existing else "Add Found Item | A-UniFind")
        window.resizable(False, False)
        window.transient(self.root)

        form = ttk.Frame(window, padding=20)
        form.pack(fill="both", expand=True)
        form.columnconfigure(1, weight=1)

        ttk.Label(
            form,
            text=f"Edit Item #{existing.item_id}" if existing else "Register a Found Item",
            font=("Segoe UI", 15, "bold"),
        ).grid(
            row=0, column=0, columnspan=2,
            sticky="w", pady=(0, 5)
        )

        ttk.Label(
            form,
            text="Fields marked * are required. ID and status stay unchanged." if existing else "Fields marked * are required.",
        ).grid(
            row=1, column=0, columnspan=2,
            sticky="w", pady=(0, 15)
        )

        name_var = tk.StringVar(value=existing.name if existing else "")
        category_var = tk.StringVar(value=existing.category if existing else "")
        location_var = tk.StringVar(value=existing.location_found if existing else "")
        date_var = tk.StringVar(value=existing.date_found if existing else date.today().isoformat())
        storage_var = tk.StringVar(value=existing.storage_location if existing else "")

        def add_entry(row, label, variable):
            ttk.Label(form, text=label).grid(
                row=row, column=0, sticky="w",
                padx=(0, 15), pady=7
            )

            entry = ttk.Entry(
                form, textvariable=variable, width=38
            )
            entry.grid(row=row, column=1, sticky="ew", pady=7)
            return entry

        name_entry = add_entry(2, "Item name *", name_var)

        ttk.Label(form, text="Category *").grid(
            row=3, column=0, sticky="w",
            padx=(0, 15), pady=7
        )

        ttk.Combobox(
            form,
            textvariable=category_var,
            values=CATEGORIES,
            state="readonly",
            width=35,
        ).grid(row=3, column=1, sticky="ew", pady=7)

        add_entry(4, "Location found *", location_var)
        add_entry(5, "Date found (YYYY-MM-DD) *", date_var)
        add_entry(6, "Storage location *", storage_var)

        ttk.Label(form, text="Private description").grid(
            row=7, column=0, sticky="nw",
            padx=(0, 15), pady=7
        )

        description_box = tk.Text(
            form, width=38, height=4, wrap="word"
        )
        description_box.grid(
            row=7, column=1, sticky="ew", pady=7
        )
        if existing:
            description_box.insert("1.0", existing.description)

        def close_form():
            window.grab_release()
            self.add_window = None
            window.destroy()

        def submit_item():
            if not self.require_staff():
                return
            name = name_var.get().strip()
            category = category_var.get().strip()
            location = location_var.get().strip()
            date_text = date_var.get().strip()
            storage = storage_var.get().strip()
            description = description_box.get(
                "1.0", "end-1c"
            ).strip()

            if not all((name, category, location, date_text, storage)):
                messagebox.showerror(
                    "Missing Information",
                    "Please complete every required field.",
                    parent=window,
                )
                return

            try:
                found_date = date.fromisoformat(date_text)

                if found_date.isoformat() != date_text:
                    raise ValueError

            except ValueError:
                messagebox.showerror(
                    "Invalid Date",
                    "Enter a valid date in YYYY-MM-DD format.\n"
                    "Example: 2026-11-12",
                    parent=window,
                )
                return

            if found_date > date.today():
                messagebox.showerror(
                    "Invalid Date",
                    "The date found cannot be in the future.",
                    parent=window,
                )
                return

            item = FoundItem(
                item_id=existing.item_id if existing else self.next_id,
                name=name,
                category=category,
                description=description,
                location_found=location,
                date_found=found_date.isoformat(),
                storage_location=storage,
                status=existing.status if existing else "Unclaimed",
            )

            # Save first. Keep the form open if saving fails.
            try:
                if existing:
                    save_records(self.items, self.next_id, replacement=item)
                else:
                    save_records(self.items, next_id=self.next_id + 1, new_item=item)
            except OSError as error:
                messagebox.showerror(
                    "Could Not Save",
                    "The changes were not applied because saving failed.\n"
                    "Your form entries have been kept. Check that the "
                    "project folder is writable and try again.\n\n"
                    f"Details: {error}",
                    parent=window,
                )
                return

            if existing:
                # Commit to the same linked-list record only after saving succeeds.
                for field, value in asdict(item).items():
                    setattr(existing, field, value)
            else:
                self.items.append(item)
                self.next_id += 1
            self.active_section = "All items"
            self.clear_search()

            row_id = str(item.item_id)
            self.item_table.selection_set(row_id)
            self.item_table.see(row_id)
            self.view_details()

            self.status_text.set(
                f'{"Updated" if existing else "Added"} and saved item #{item.item_id}: "{item.name}".'
            )

            close_form()

        buttons = ttk.Frame(form)
        buttons.grid(
            row=8, column=0, columnspan=2,
            sticky="e", pady=(15, 0)
        )

        ttk.Button(
            buttons, text="Cancel", command=close_form
        ).pack(side="left", padx=(0, 8))

        ttk.Button(
            buttons, text="Save Changes" if existing else "Add Item", command=submit_item
        ).pack(side="left")

        window.protocol("WM_DELETE_WINDOW", close_form)
        window.bind("<Escape>", lambda event: close_form())
        window.grab_set()
        name_entry.focus_set()


def run_app():
    root = tk.Tk()
    root.withdraw()

    try:
        items, next_id = load_records()
    except (OSError, ValueError) as error:
        messagebox.showerror(
            "Could Not Load Records",
            "The saved records could not be loaded.\n"
            "The app will close to avoid overwriting them.\n"
            "Keep the file and report this error for troubleshooting.\n\n"
            f"File: {DATA_FILE}\n\n"
            f"Details: {error}",
            parent=root,
        )
        root.destroy()
        return

    try:
        app = LostAndFoundApp(root, items, next_id)
    except (sqlite3.Error, OSError) as error:
        messagebox.showerror("Account File Error", f"Could not open staff account storage.\n\n{error}", parent=root)
        root.destroy()
        return
    root.deiconify()
    root.mainloop()


def main():
    lock = SingleInstanceLock(DATA_FILE.with_suffix(".lock"))
    try:
        acquired = lock.acquire()
    except OSError as error:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror(
            "Could Not Start",
            f"Could not protect the records file. A-UniFind will close.\n\n{error}",
            parent=root,
        )
        root.destroy()
        return
    if not acquired:
        root = tk.Tk()
        root.withdraw()
        messagebox.showinfo(
            "A-UniFind Is Already Open",
            "Another copy is already using these records.\n"
            "Use the existing window, or close it before opening another copy.",
            parent=root,
        )
        root.destroy()
        return
    try:
        run_app()
    finally:
        lock.release()


if __name__ == "__main__":
    main()
